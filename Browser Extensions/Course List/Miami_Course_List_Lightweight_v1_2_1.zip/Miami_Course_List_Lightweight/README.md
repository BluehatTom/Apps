# Miami Course List Lightweight — v1.2.1

A compact Chrome/Edge browser extension for **Miami University's Course List only**. Save course search filters as quick buttons, search automatically when choosing a delivery modality, and **export/import backups** to restore presets after reinstalling or transfer them to another computer.

**Course List:** https://www.apps.miamioh.edu/courselist/

## Install or update

### First-time installation

1. Extract `Miami_Course_List_Lightweight_v1_2_1.zip` somewhere permanent (for example, in a folder inside Documents).
2. Open `chrome://extensions` (Chrome) or `edge://extensions` (Edge).
3. Turn on **Developer mode**, select **Load unpacked**, and choose the extracted **Miami_Course_List_Lightweight** folder that directly contains `manifest.json`.
4. Open or refresh the Miami Course List website. The side panel appears automatically.

### Update from v1.0 through v1.2.0 — keep your existing presets

1. **Do not uninstall the currently installed extension** or delete its folder.
2. Extract the new ZIP to a temporary location and copy all five files (`content.js`, `data.js`, `background.js`, `manifest.json`, and `README.md`) **into the exact folder** used by the existing extension, replacing the old files.
3. In `chrome://extensions` / `edge://extensions`, click **Reload** for the existing extension; close and reopen every Course List tab so each tab uses the new scripts.
4. Your old presets and panel preferences remain available. This release keeps the original Chrome extension storage key (`mcl_lite_presets_v1`) and existing data format.
5. You can now use **Backup & restore → Export backup** to create an external copy for future updates or transferring computers.

**Important:** An extension loaded unpacked from an entirely different folder can be treated as a new extension identity, so it may not see saved data from the original folder. Use the same folder to update. Once the new Backup & restore feature is installed, make a JSON backup **before uninstalling, moving the folder, or switching computers**.

## Presets and modality

1. **Save:** Set Term, Campus, Subject, Course Number, or other Course List filters on the actual webpage. Type a name in **Save current search as** and click **Save**.
2. **Recall:** Click the preset button under **Saved filters**. It restores the filters but **does not** automatically run Find. Click **Find courses** when ready.
3. **Modality:** Choose a value from the dropdown below the saved-filter buttons. It updates the site's Alternative Delivery Types checkboxes and **automatically runs Find**. Other filters remain unchanged.
4. **Delete:** Click a preset button and then **Delete selected**. Confirm the deletion.
5. **Auto-restore:** When enabled, the last applied preset is restored on a future visit. It does not run a search automatically.

### Modality options

Any modality (clear filter), Face-to-Face, Online Synchronous, Online Asynchronous, Hybrid Synchronous, Hybrid Asynchronous, Interactive Video Distance Learning, Study Abroad, Study Away.

The Course List page itself permits several delivery types to be selected manually. The extension's dropdown is single-choice. If several types are selected on the site, the dropdown displays **Multiple selected on page**; you can still save that state in a preset.

## Backup & restore

At the bottom of the panel, expand **Backup & restore**. This section is collapsed by default to keep the panel small.

### Export your presets and settings

1. Save any current webpage filters as a preset first if you want them included.
2. Click **Export backup**. Your browser downloads a file named like `Miami_Course_List_Backup_2026-10-29.json`.
3. Keep that `.json` file somewhere safe, such as Documents, an external drive, or your usual file storage.

The JSON backup includes **all saved filter presets and panel preferences** (auto-restore, side, collapsed state, last-applied selection). It contains **no password or authentication token** and does not use a server, AI, or cloud account. **Unsaved filters currently set on the Course List webpage are not included**—save them as a preset first.

### Restore after changing versions or installing on another computer

1. Install v1.2.1 or newer on the other computer (or update the existing installation).
2. On the Course List page, expand **Backup & restore**.
3. Under **When importing**, choose:
   - **Restore everything (replace current)** — replaces saved presets **and panel settings** with those from the file. This is the default, and it asks for confirmation if the extension already contains presets.
   - **Add presets (keep current settings)** — retains existing presets and panel preferences and adds the presets from the file. Exact matches are skipped; a different preset with the same name is renamed with `(imported)` to avoid overwriting.
4. Click **Import backup** and choose the exported `.json` file.
5. The panel reports how many presets were restored or added. Preset buttons appear immediately; no browser restart is required.

**Precautions:** Import rejects invalid or unsupported backup files without altering current presets. The file limit is 2 MB, and there is a maximum of 50 saved presets. Keep your backup file until you verify that the presets work on the destination computer.

## UI controls

- **Quick instructions:** always at the top; expand/collapse as needed.
- **Saved filters:** buttons, not a dropdown.
- **Find courses:** runs the site's Find action when pressed.
- **Modality:** dropdown below Saved filters; triggers Find when changed.
- **Save / Delete selected:** manage presets.
- **Backup & restore:** expandable export/import section.
- **Move panel / Minimize:** change panel side or collapse it to a tab.

## Privacy and compatibility

- Runs only on the Course List site at `https://www.apps.miamioh.edu/courselist/` (with or without `www`).
- Does not read passwords, account credentials, hidden fields, or email/phone/account identifiers.
- Stores presets in `chrome.storage.local`. Normal updates within the same extension installation preserve these values.
- Backups are plain JSON files downloaded by your browser; the extension does not upload data anywhere.
- If the site's filter controls change significantly, some restored fields may need manual checking. Modality Find is blocked if the extension cannot identify its delivery-type checkboxes reliably.

## Changes in v1.2.1

- All tabs send state operations to one background worker. Preference changes cannot overwrite another tab's presets. Simultaneous saves are serialized; conflicting overwrites, deletes, or whole-backup replacements are rejected with a message to check the updated list and retry.
- Saved buttons and panel settings synchronize between open Course List tabs.
- Checkbox and radio restoration requires the saved option value. Missing options produce a warning instead of changing a different option.
- Restoration rechecks every field for up to 6.5 seconds and requires one second of matching values before reporting success. This repairs dependent filters reset during a normal asynchronous update. Updates arriving after that bounded observation period can still require manual checking.
- Imports allow only supported filter types. Every restoration lookup, including ID lookup, checks the actual target against the privacy exclusions.
- The storage key and JSON backup schema are unchanged. Supported v1.2.0 backups remain compatible. The extension still requests only the storage permission.

## Testing

The included companion test files under outputs/tests exercise the production scripts:

- 18 Node regression tests cover serialized operations across tabs, conflicting edits, backup merge/replace, limits, failed reads/writes, legacy backup compatibility, unsafe types, strict checkbox matching, and sensitive target exclusions.
- 13 headless Chrome fixture checks cover save/recall, tab synchronization, delayed Campus/Subject resets, concurrent saves, write failures, actual JSON downloads, merge, invalid imports, missing options, modality search, canceled and confirmed replacement, and auto-restore.

The Chrome fixture uses a mocked Chrome API bridge to the production background worker. It does not validate extension installation or the actual Chrome service-worker lifecycle. The live Miami site has not been end-to-end tested. Prior v1.2.0 documentation claimed 44 browser checks, but that test suite was not supplied.

Run the Node suite from the parent outputs directory:

```text
node --test tests/regression.test.cjs
```

The browser test requires Playwright and a Chrome executable; see tests/browser-smoke.cjs for environment overrides.

## Included extension files

- manifest.json: extension metadata, site restrictions, worker registration, and local storage permission.
- background.js: serialized state mutations across tabs and storage conflict checks.
- data.js: shared backup validation and state helpers.
- content.js: side panel, search presets, modality selection, backup and restore.
- README.md: installation and usage instructions.
