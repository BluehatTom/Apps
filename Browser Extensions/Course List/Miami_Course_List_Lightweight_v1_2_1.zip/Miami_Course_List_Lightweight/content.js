/*
 * Miami Course List - Lightweight Presets (v1.2.1)
 * In-page panel; no external services; a modality change runs the site Find search.
 * Runs only at https://(www.)apps.miamioh.edu/courselist/...
 */
(() => {
  'use strict';

  if (window.top !== window.self || document.getElementById('mcl-lite-host')) return;
  const STORAGE_KEY = 'mcl_lite_presets_v1';
  const ALLOWED_PATH = /^\/courselist(?:\/|$)/i;
  if (!/^(?:www\.)?apps\.miamioh\.edu$/i.test(location.hostname) ||
      !ALLOWED_PATH.test(location.pathname)) return;

  const FILTER_WORDS = /\b(term|campus|subject|course\s*(?:number|no\.?|level)|attribute|delivery|modality|face.to.face|hybrid|study|open|waitlist|crn|part\s*of\s*term|level|title|instructor|day|credit|start\s*time|end\s*time|class\s*time|hours)\b/i;
  const SENSITIVE_WORDS = /(password|passcode|passwd|security|secret|token|csrf|authenticat|session|captcha|credential|email|phone|user_?id|student_?id)/i;
  const SEARCH_WIDGET_WORDS = /(search[-_ ]?(?:input|box|field)|select2-search|multiselect-filter|dropdown-search)/i;
  const MAX_PRESETS = 50;
  const BACKUP_FORMAT = 'miami-course-list-lightweight-backup';
  const BACKUP_SCHEMA = 1;
  const MAX_BACKUP_BYTES = 2 * 1024 * 1024;
  const AUTO_RESTORE_DELAY = 950;
  // Miami calls modalities "Alternative Delivery Types". Its site exposes individual checkboxes.
  // Match by the site's visible labels rather than assuming stable IDs or numeric checkbox values.
  const MODALITIES = [
    { key: 'face', label: 'Face-to-Face', aliases: ['face to face', 'face-to-face'] },
    { key: 'online-sync', label: 'Online Synchronous', aliases: ['online synchronous'] },
    { key: 'online-async', label: 'Online Asynchronous', aliases: ['online asynchronous'] },
    { key: 'hybrid-sync', label: 'Hybrid Synchronous', aliases: ['hybrid synchronous'] },
    { key: 'hybrid-async', label: 'Hybrid Asynchronous', aliases: ['hybrid asynchronous'] },
    { key: 'video', label: 'Interactive Video Distance Learning', aliases: ['interactive video distance learning', 'interactive video dist learn'] },
    { key: 'abroad', label: 'Study Abroad', aliases: ['study abroad'] },
    { key: 'away', label: 'Study Away', aliases: ['study away'] }
  ];

  let state = { presets: [], selectedId: null, lastAppliedId: null, autoRestore: false, side: 'right', collapsed: false };
  let panel, host, shadow, ui = {};
  let busy = false;
  let statusTimer = null;

  const STORAGE = {
    get() {
      return new Promise((resolve, reject) => {
        try {
          chrome.storage.local.get(STORAGE_KEY, result => {
            if (chrome.runtime?.lastError) return reject(new Error(chrome.runtime.lastError.message));
            resolve(result?.[STORAGE_KEY] || null);
          });
        } catch (err) { reject(err); }
      });

    }
  };

  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  const norm = s => String(s ?? '').replace(/\s+/g, ' ').replace(/[\u00a0*]+/g, ' ').trim();
  const keyText = s => norm(s).toLowerCase().replace(/[^a-z0-9]+/g, '');
  const trimLabel = s => norm(s).replace(/\s*:?\s*$/, '').slice(0, 120);
  const id = () => 'p_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
  const byId = x => document.getElementById(x);
  const escapeCSS = v => (globalThis.CSS?.escape ? CSS.escape(String(v)) : String(v).replace(/([^a-zA-Z0-9_-])/g, '\\$1'));

  function storageSafeState() {
    return {
      presets: state.presets.slice(0, MAX_PRESETS),
      selectedId: state.selectedId,
      lastAppliedId: state.lastAppliedId,
      autoRestore: !!state.autoRestore,
      side: state.side === 'left' ? 'left' : 'right',
      collapsed: !!state.collapsed
    };
  }
  async function commit(operation) {
    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ channel: 'mcl-state', ...operation }, result => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else if (!result?.ok) reject(new Error(result?.error || 'No response from extension. Reload the extension and refresh this page.'));
        else resolve(result);
      });
    });
    state = globalThis.MCLData.normalize(response.state);
    return response;
  }
  async function refreshState() {
    const saved = await STORAGE.get();
    if (!busy) {
      state = globalThis.MCLData.normalize(saved);
      if (host) { placeHost(); render(); }
    }
  }
  async function finishOperation() {
    try {
      const saved = await STORAGE.get();
      state = globalThis.MCLData.normalize(saved);
    } catch (err) { setStatus('Could not refresh saved presets: ' + err.message, 'error'); }
    busy = false;
    placeHost();
    render(); syncModalityFromPage();
  }

  // Export plain JSON so the same presets can be imported after reinstalling or
  // moved to another computer. Do not change STORAGE_KEY across extension updates.
  function backupDocument() {
    return {
      format: BACKUP_FORMAT,
      schemaVersion: BACKUP_SCHEMA,
      extensionVersion: '1.2.1',
      exportedAt: new Date().toISOString(),
      settings: storageSafeState()
    };
  }

  const { parseBackup, INPUT_TYPES } = globalThis.MCLData;

  function exportBackup() {
    if (busy) return;
    try {
      const contents = JSON.stringify(backupDocument(), null, 2) + '\n';
      const blob = new Blob([contents], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'Miami_Course_List_Backup_' + new Date().toISOString().slice(0, 10) + '.json';
      document.body.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      setStatus('Backup downloaded: ' + state.presets.length + ' presets and panel settings. Keep the JSON file to restore later or import on another computer.', 'ok');
    } catch (err) { setStatus('Could not export backup: ' + (err?.message || 'unknown error'), 'error'); }
  }

  async function importBackup(file) {
    if (!file || busy) return;
    if (file.size > MAX_BACKUP_BYTES) { setStatus('Backup is too large (maximum 2 MB). Nothing was changed.', 'error'); return; }
    busy = true;
    render();
    try {
      const imported = parseBackup(await file.text());
      const mode = ui.importMode.value;
      await commit({ action: 'read' });
      let message;
      if (mode === 'replace') {
        if (state.presets.length && !window.confirm(
          'Restore this backup? This will REPLACE all ' + state.presets.length +
          ' existing presets and panel settings with the ' + imported.presets.length + ' presets in the file.'
        )) { setStatus('Import canceled; nothing was changed.', 'info'); return; }
        await commit({ action: 'replace', imported, expected: storageSafeState() });
        message = 'Restored ' + state.presets.length + ' presets and panel settings from backup.';
      } else {
        const result = await commit({ action: 'merge', imported });
        message = 'Added ' + result.added + ' presets; skipped ' + result.skipped +
          ' already present' + (result.renamed ? '; renamed ' + result.renamed + ' conflicts' : '') + '. Current panel settings were kept.';
      }
      // The worker persisted successfully before returning the new state.
      placeHost();
      setStatus(message, 'ok');
    } catch (err) {
      setStatus('Import failed: ' + (err?.message || 'unknown error') + ' Nothing was changed.', 'error');
    } finally {
      await finishOperation();
    }
  }
  function setStatus(message, kind = 'info') {
    if (!ui.status) return;
    if (statusTimer) clearTimeout(statusTimer);
    ui.status.textContent = message;
    ui.status.dataset.kind = kind;
    statusTimer = null;
  }

  function looksSearchWidgetInput(el) {
    const attrs = [el.name, el.id, el.className, el.getAttribute('placeholder')].join(' ');
    if (SEARCH_WIDGET_WORDS.test(attrs)) return true;
    if (!el.id && !el.name && (el.type === 'search' || /^search\b/i.test(el.placeholder || '')) &&
        el.closest('[role="listbox"], [class*="dropdown"], [class*="select2"], [class*="multiselect"]')) return true;
    return false;
  }

  function getFieldRoot() {
    // Prefer the actual course search form, not a login or navigation form.
    const forms = [...document.querySelectorAll('form')];
    const score = el => {
      const text = norm(el.innerText || el.textContent || '');
      return (/\bTerm\b/i.test(text) ? 2 : 0) +
        (/\bCampus\b/i.test(text) ? 3 : 0) +
        (/\bSubject\b/i.test(text) ? 2 : 0) +
        (/Course Number/i.test(text) ? 2 : 0) +
        (/Advanced Search/i.test(text) ? 1 : 0);
    };
    forms.sort((a, b) => score(b) - score(a));
    if (forms.length && score(forms[0]) >= 4) return { root: forms[0], confident: true };
    const candidates = [...document.querySelectorAll('main, [role="main"], #main, #app, #root, .container')];
    candidates.sort((a, b) => score(b) - score(a));
    if (candidates.length && score(candidates[0]) >= 4) return { root: candidates[0], confident: true };
    return { root: document.body, confident: false };
  }

  function fieldLabel(el) {
    const fromLabels = [...(el.labels || [])].map(l => trimLabel(l.textContent)).filter(Boolean);
    if (fromLabels.length) return fromLabels[0];
    const aria = el.getAttribute('aria-label');
    if (aria) return trimLabel(aria);
    const labelled = el.getAttribute('aria-labelledby');
    if (labelled) {
      const text = labelled.split(/\s+/).map(part => byId(part)?.textContent || '').join(' ');
      if (norm(text)) return trimLabel(text);
    }
    const wrapped = el.closest('label');
    if (wrapped) return trimLabel(wrapped.textContent);
    const grouping = el.closest('fieldset, .form-group, .form-field, .filter-group, .control-group, [class*="filter-row"], [class*="form-field"]');
    if (grouping) {
      const l = grouping.querySelector('legend, label, [class*="label"]');
      if (l) return trimLabel(l.textContent);
    }
    const parent = el.parentElement;
    if (parent) {
      const l = parent.querySelector(':scope > label, :scope > legend, :scope > strong');
      if (l) return trimLabel(l.textContent);
      const sibling = el.previousElementSibling;
      if (sibling && /^(LABEL|LEGEND|STRONG|SPAN)$/.test(sibling.tagName)) return trimLabel(sibling.textContent);
    }
    return trimLabel(el.getAttribute('placeholder') || el.getAttribute('name') || el.id || '');
  }

  function isRelevant(el, rootInfo) {
    if (!el.isConnected || host?.contains(el)) return false;
    if (el.closest('header, nav, footer, [role="navigation"], [role="banner"], [role="contentinfo"]')) return false;
    if (el.closest('[data-mcl-ignore], #mcl-lite-host')) return false;
    if (!rootInfo.root.contains(el)) return false;
    const type = (el.type || '').toLowerCase();
    if (['hidden', 'password', 'email', 'file', 'submit', 'reset', 'button', 'image', 'color'].includes(type)) return false;
    if (!['INPUT', 'SELECT', 'TEXTAREA'].includes(el.tagName)) return false;
    if (el.tagName === 'INPUT' && !INPUT_TYPES.has(type)) return false;
    if (SENSITIVE_WORDS.test([el.name, el.id, el.autocomplete, fieldLabel(el)].join(' '))) return false;
    if (looksSearchWidgetInput(el)) return false;
    if (type === 'checkbox' && /^(select all|check all|unselect all)$/i.test(fieldLabel(el))) return false;
    if (el.closest('.select2-dropdown, .ng-dropdown-panel, [role="listbox"]') && el.tagName !== 'SELECT' &&
        !el.name && !el.id) return false;
    // If the search is built without a <form>, limit collection to course filter controls.
    if (!rootInfo.confident) {
      const context = [fieldLabel(el), el.name, el.id, el.placeholder, el.closest('fieldset, .form-group')?.textContent?.slice(0, 110)].join(' ');
      return FILTER_WORDS.test(context);
    }
    return true;
  }

  function domPath(el, root) {
    const pieces = [];
    for (let node = el; node && node !== root && node !== document.body; node = node.parentElement) {
      let token = node.tagName.toLowerCase();
      if (node.id && !/^\d/.test(node.id) && !/^(?:react-select|ng-)/i.test(node.id)) {
        token += '#' + escapeCSS(node.id);
        pieces.unshift(token);
        break;
      }
      const parent = node.parentElement;
      if (parent) {
        const peers = [...parent.children].filter(n => n.tagName === node.tagName);
        if (peers.length > 1) token += ':nth-of-type(' + (peers.indexOf(node) + 1) + ')';
      }
      pieces.unshift(token);
      if (pieces.length > 12) break;
    }
    return pieces.join(' > ');
  }

  function fieldDescriptor(el, root, groupIndex) {
    const type = el.tagName === 'SELECT' ? 'select' : el.tagName === 'TEXTAREA' ? 'textarea' : (el.type || 'text').toLowerCase();
    const label = fieldLabel(el);
    const name = el.getAttribute('name') || '';
    const identifier = el.id || '';
    const key = [el.tagName.toLowerCase(), type, name || identifier || keyText(label), groupIndex].join('|');
    return { key, tag: el.tagName, type, name, id: identifier, label, ordinal: groupIndex, path: domPath(el, root) };
  }

  function nativeFieldSnapshot() {
    const rootInfo = getFieldRoot();
    const els = [...rootInfo.root.querySelectorAll('input, select, textarea')].filter(el => isRelevant(el, rootInfo));
    const seen = new Map();
    const fields = els.map(el => {
      const type = el.tagName === 'SELECT' ? 'select' : el.tagName === 'TEXTAREA' ? 'textarea' : (el.type || 'text').toLowerCase();
      const marker = [el.tagName, type, el.name || el.id || keyText(fieldLabel(el))].join('|');
      const ordinal = seen.get(marker) || 0;
      seen.set(marker, ordinal + 1);
      const d = fieldDescriptor(el, rootInfo.root, ordinal);
      let value;
      if (type === 'checkbox' || type === 'radio') value = !!el.checked;
      else if (el.tagName === 'SELECT' && el.multiple) value = [...el.selectedOptions].map(o => ({ value: o.value, text: norm(o.textContent) }));
      else if (el.tagName === 'SELECT') {
        const selected = el.options[el.selectedIndex];
        value = { value: el.value, text: norm(selected?.textContent || '') };
      } else value = el.value;
      // Checkboxes may have the same name (e.g. Subject), so remember option value.
      d.optionValue = type === 'checkbox' || type === 'radio' ? el.value : '';
      return { ...d, value };
    });
    return fields;
  }

  function findField(saved, rootInfo) {
    const all = [...rootInfo.root.querySelectorAll('input, select, textarea')].filter(el => isRelevant(el, rootInfo));
    const sameType = el => el.tagName === saved.tag &&
      (saved.tag === 'SELECT' || saved.tag === 'TEXTAREA' || (el.type || 'text').toLowerCase() === saved.type);
    // Names are usually stable even when the course page rerenders.
    const byName = saved.name ? all.filter(el => sameType(el) && el.name === saved.name) : [];
    const matches = list => {
      if (saved.type === 'checkbox' || saved.type === 'radio') {
        const byValue = list.filter(el => el.value === saved.optionValue);
        if (byValue.length === 1) return byValue[0];
        if (byValue.length > 1) {
          const exact = byValue.filter(el => (saved.id && el.id === saved.id) || (saved.label && keyText(fieldLabel(el)) === keyText(saved.label)));
          return exact.length === 1 ? exact[0] : null;
        }
        return null;
      }
      return list[saved.ordinal] || list[0] || null;
    };
    if (byName.length) { const match = matches(byName); if (match) return match; }
    if (saved.id) {
      const byElementId = byId(saved.id);
      if (byElementId && isRelevant(byElementId, rootInfo) && sameType(byElementId) &&
          (!['checkbox', 'radio'].includes(saved.type) || byElementId.value === saved.optionValue)) return byElementId;
    }
    if (saved.label) {
      const group = all.filter(el => sameType(el) && keyText(fieldLabel(el)) === keyText(saved.label));
      if (group.length) return matches(group);
    }
    if (saved.path) {
      try {
        const candidate = rootInfo.root.querySelector(saved.path);
        if (candidate && sameType(candidate) && isRelevant(candidate, rootInfo) &&
            (!['checkbox', 'radio'].includes(saved.type) || candidate.value === saved.optionValue)) return candidate;
      } catch { /* site structure changed */ }
    }
    return null;
  }

  function setInputValue(el, value) {
    const target = String(value ?? '');
    if (el.value === target) return false;
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, target);
    else el.value = target;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }
  function announceChanges(el) {
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function chooseOption(select, saved) {
    const options = [...select.options];
    return options.find(o => o.value === saved.value) ||
      options.find(o => norm(o.textContent).toLowerCase() === norm(saved.text).toLowerCase());
  }

  function setNative(saved) {
    const rootInfo = getFieldRoot();
    const el = findField(saved, rootInfo);
    if (!el) return 'missing';
    if (el.disabled) return 'disabled';
    const type = saved.type;
    if (type === 'checkbox' || type === 'radio') {
      const want = !!saved.value;
      if (el.checked !== want) {
        el.checked = want;
        announceChanges(el);
      }
      return 'ok';
    }
    if (saved.tag === 'SELECT') {
      if (el.multiple) {
        const wanted = Array.isArray(saved.value) ? saved.value : [];
        const targets = wanted.map(opt => chooseOption(el, opt));
        if (targets.some(o => !o)) return 'options-not-ready';
        const values = new Set(targets.map(o => o.value));
        let changed = false;
        for (const option of el.options) {
          const selected = values.has(option.value);
          if (option.selected !== selected) { option.selected = selected; changed = true; }
        }
        if (changed) announceChanges(el);
        return 'ok';
      }
      const target = chooseOption(el, saved.value || { value: '', text: '' });
      if (!target) return 'options-not-ready';
      if (el.value !== target.value) { el.value = target.value; announceChanges(el); }
      return 'ok';
    }
    setInputValue(el, saved.value);
    return 'ok';
  }

  function orderFields(fields) {
    const weight = f => {
      const name = [f.name, f.id, f.label].join(' ');
      if (/\bterm\b/i.test(name)) return 0;
      if (/\bcampus\b/i.test(name)) return 1;
      if (/\bsubject\b/i.test(name)) return 2;
      return 3;
    };
    return [...fields].sort((a, b) => weight(a) - weight(b));
  }

  function fieldMatches(saved) {
    const el = findField(saved, getFieldRoot());
    if (!el || el.disabled) return false;
    if (saved.type === 'checkbox' || saved.type === 'radio') return el.checked === saved.value;
    if (saved.tag === 'SELECT') {
      const wanted = Array.isArray(saved.value) ? saved.value : [saved.value];
      const targets = wanted.map(opt => chooseOption(el, opt));
      if (targets.some(opt => !opt)) return false;
      const selected = [...el.selectedOptions];
      return selected.length === targets.length && targets.every(opt => selected.includes(opt));
    }
    return el.value === String(saved.value ?? '');
  }

  async function restoreNativeFields(fields) {
    const ordered = orderFields(fields);
    const deadline = Date.now() + 6500;
    let stableSince = null;
    // Recheck every field, including earlier successes, because the site can
    // replace or clear dependent controls after a parent change has completed.
    while (Date.now() < deadline) {
      let changed = false;
      for (const field of ordered) {
        if (!fieldMatches(field)) {
          changed = true;
          setNative(field);
          if (/\b(term|campus)\b/i.test([field.name, field.id, field.label].join(' '))) await wait(300);
        }
      }
      const allMatch = ordered.every(fieldMatches);
      if (changed || !allMatch) stableSince = null;
      else if (stableSince === null) stableSince = Date.now();
      // Observe a full second of matching final values rather than accepting
      // a value set on a control that is about to be asynchronously replaced.
      if (stableSince !== null && Date.now() - stableSince >= 1000) break;
      await wait(175);
    }
    const pending = ordered.filter(field => !fieldMatches(field));
    const stable = stableSince !== null && Date.now() - stableSince >= 1000;
    return {
      completed: ordered.length - pending.length, total: ordered.length,
      missing: [...new Set(pending.map(f => trimLabel(f.label || f.name || f.id || f.type)))],
      stable
    };
  }

  function modalityKeyForCheckbox(el) {
    const candidates = [
      ...[...(el.labels || [])].map(l => l.textContent),
      el.getAttribute('aria-label'),
      (el.getAttribute('aria-labelledby') || '').split(/\s+/).map(id => byId(id)?.textContent || '').join(' '),
      el.closest('label')?.textContent,
      el.nextElementSibling?.matches('label, span, strong') ? el.nextElementSibling.textContent : '',
      el.previousElementSibling?.matches('label, span, strong') ? el.previousElementSibling.textContent : '',
      el.parentElement?.matches('label, .form-check, .checkbox, .checkbox-item') ? el.parentElement.textContent : ''
    ].filter(Boolean);
    for (const value of candidates) {
      const readable = keyText(value);
      const match = MODALITIES.find(item => item.aliases.some(alias => {
        const key = keyText(alias);
        // A label may include a short explanation following the modality name.
        return readable === key || (readable.startsWith(key) && readable.length < key.length + 90);
      }));
      if (match) return match.key;
    }
    // Fallback for inputs whose labels are only attached through CSS; do not
    // identify from a giant parent container that lists every delivery type.
    const attr = keyText([el.name, el.id].join(' '));
    return MODALITIES.find(item => item.aliases.some(alias => attr.includes(keyText(alias))))?.key || null;
  }

  function modalityCheckboxes() {
    const rootInfo = getFieldRoot();
    const found = new Map();
    const duplicates = new Set();
    for (const input of rootInfo.root.querySelectorAll('input[type="checkbox"]')) {
      if (!isRelevant(input, rootInfo) || input.disabled) continue;
      const key = modalityKeyForCheckbox(input);
      if (!key) continue;
      if (found.has(key)) duplicates.add(key);
      else found.set(key, input);
    }
    for (const key of duplicates) found.delete(key);
    return found;
  }

  function syncModalityFromPage() {
    if (!ui.modality || busy) return;
    const controls = modalityCheckboxes();
    if (controls.size < 6) { ui.modality.value = ''; return; }
    const selected = [...controls].filter(([, el]) => el.checked).map(([key]) => key);
    ui.modality.value = selected.length === 0 ? 'any' : selected.length === 1 ? selected[0] : 'multiple';
  }

  async function selectModalityAndFind() {
    if (busy) return;
    const choice = ui.modality.value;
    if (!choice || choice === 'multiple') return;
    const controls = modalityCheckboxes();
    if (controls.size < 6 || (choice !== 'any' && !controls.has(choice))) {
      setStatus('Could not identify the Course List delivery-type controls reliably. No search was run; choose the modality on the page instead.', 'warn');
      syncModalityFromPage();
      return;
    }
    busy = true;
    render();
    setStatus('Setting modality and searching...', 'info');
    try {
      // First uncheck other modalities, then select the one requested.
      // Re-query each input because the site can re-render controls after a click.
      const keys = [...controls.keys()].filter(k => k !== choice);
      if (choice !== 'any') keys.push(choice);
      for (const key of keys) {
        const input = modalityCheckboxes().get(key);
        if (!input || !input.isConnected || input.disabled) throw new Error('A delivery-type control disappeared while updating.');
        const desired = key === choice;
        if (input.checked !== desired) {
          input.click(); // Actual click triggers the site's own change handlers.
          await wait(35);
        }
      }
      await wait(140);
      const after = modalityCheckboxes();
      const correct = [...controls.keys()].every(key => after.has(key) && after.get(key).checked === (key === choice));
      if (!correct) {
        setStatus('Delivery type could not be confirmed. Check the filters on the page before searching.', 'warn');
        return;
      }
      runFind('modality');
    } catch (err) {
      setStatus('Unable to set modality: ' + (err?.message || 'unknown error') + '. No search was run.', 'error');
    } finally {
      busy = false;
      render();
      syncModalityFromPage();
    }
  }

  function findFindButton() {
    const root = getFieldRoot().root;
    const candidates = [...root.querySelectorAll('button, input[type="submit"], input[type="button"]')];
    return candidates.find(b => /^find(?: courses)?$/i.test(norm(b.textContent || b.value))) ||
      candidates.find(b => /^(?:search|search courses)$/i.test(norm(b.textContent || b.value))) || null;
  }

  const CSS_TEXT = `
    :host { all: initial; color-scheme: light; }
    *, *::before, *::after { box-sizing: border-box; }
    .mcl-panel, .mcl-peek { font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
    .mcl-panel { width: 300px; max-width: min(300px, calc(100vw - 30px)); max-height: calc(100vh - 24px); overflow: hidden; color: #27282e;
      background: #fff; border: 1px solid #d8dce4; border-radius: 13px; box-shadow: 0 8px 32px rgba(20,26,34,.2); font-size: 13px; }
    .mcl-header { background: #b31b34; color: #fff; padding: 11px 12px 10px; display: flex; align-items: center; justify-content: space-between; gap: 10px; }
    .mcl-heading { font-size: 14px; font-weight: 750; letter-spacing: -.01em; line-height: 1.25; margin: 0; }
    .mcl-subheading { color: #ffdee5; font-size: 10.5px; line-height: 1.5; margin-top: 2px; }
    .mcl-header-actions { display: flex; gap: 4px; }
    button { cursor: pointer; font: inherit; }
    .mcl-icon { width: 28px; height: 28px; border: 1px solid rgba(255,255,255,.35); border-radius: 6px; background: rgba(255,255,255,.12); color:#fff; display:flex; align-items:center; justify-content:center; font-size: 17px; }
    .mcl-icon:hover, .mcl-icon:focus-visible { background: rgba(255,255,255,.25); }
    .mcl-body { padding: 12px; max-height: calc(100vh - 86px); overflow-y: auto; overflow-x: hidden; }
    .mcl-section { margin-bottom: 13px; }
    .mcl-section:last-child { margin-bottom: 0; }
    .mcl-label { display: block; font-size: 11.5px; font-weight: 700; color: #3c4250; margin-bottom: 5px; }
    .mcl-row { display: flex; align-items: center; gap: 6px; }
    .mcl-input, .mcl-select { display: block; width: 100%; border: 1px solid #b8c0ce; border-radius: 6px; padding: 8px 9px; min-height: 34px; background: white; color: #232631; font: inherit; min-width: 0; }
    .mcl-btn { border: 1px solid #b7bfcd; background: #f7f8fb; padding: 8px 10px; border-radius: 6px; color: #28303c; font-weight: 650; white-space: nowrap; min-height: 34px; }
    .mcl-btn.primary { background: #b31b34; color:#fff; border-color:#b31b34; }
    .mcl-btn.secondary { background: #fff; }
    .mcl-btn:hover:not(:disabled) { filter: brightness(.96); }
    .mcl-btn:disabled { opacity: .55; cursor: default; }
    .mcl-btn.fill { flex: 1; }
    .mcl-btn.compact { font-size: 11px; padding: 7px 9px; }
    .mcl-small { font-size: 11px; color: #626a78; line-height: 1.45; }
    .mcl-line { border-top: 1px solid #edf0f3; margin: 11px 0; }
    .mcl-quick { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 7px; max-height: 130px; overflow-y:auto; }
    .mcl-quick button { max-width:100%; overflow:hidden; text-overflow: ellipsis; white-space: nowrap; border-radius: 16px; padding: 6px 10px; border:1px solid #cad0da; background:#f6f8fc; color:#283344; font-size: 11.5px; font-weight: 600; }
    .mcl-quick button[aria-current="true"] { background: #fae7eb; border-color: #b31b34; color:#8c1026; }
    .mcl-quick button:hover { border-color: #b31b34; }
    .mcl-checkbox { display: flex; align-items: flex-start; gap: 6px; font-size: 11.5px; color:#373b44; cursor: pointer; line-height: 1.4; }
    .mcl-checkbox input { width: 15px; height: 15px; margin:1px 0 0; accent-color:#b31b34; }
    .mcl-status { margin-top: 11px; border-radius:6px; padding: 7px 8px; color:#344258; background:#f0f3f8; min-height:32px; font-size:11.25px; line-height:1.45; overflow-wrap: anywhere; }
    .mcl-status[data-kind="ok"] { background:#eef7ef; color:#285832; }
    .mcl-status[data-kind="warn"] { background:#fff7e6; color:#775217; }
    .mcl-status[data-kind="error"] { background:#fff0ef; color:#8a2020; }
    .mcl-guide { border-top: 1px solid #e9edf3; padding-top: 9px; }
    .mcl-guide-top { border-top: none; border-bottom: 1px solid #e9edf3; padding: 0 0 10px; margin-bottom: 12px; }
    .mcl-guide summary { cursor:pointer; color:#47536b; font-weight:650; font-size:11.75px; }
    .mcl-guide ol { padding-left: 18px; margin:8px 0 3px; color:#4b5260; font-size:11.5px; line-height:1.55; }
    .mcl-guide li { margin: 0 0 4px; }
    .mcl-backup { margin-top: 13px; padding-top: 11px; }
    .mcl-backup summary { color: #303c56; }
    .mcl-backup-body { padding-top: 9px; }
    .mcl-backup-actions { display:flex; gap:6px; margin-top:10px; }
    .mcl-backup-actions .mcl-btn { flex: 1; min-width: 0; }
    .mcl-peek { display:none; background:#b31b34; color:white; border:1px solid #fff; border-radius:9px; padding:9px 11px; box-shadow:0 5px 19px #1723333f; font-size:12px; font-weight:700; }
    :host([data-collapsed="true"]) .mcl-panel { display:none; }
    :host([data-collapsed="true"]) .mcl-peek { display:block; }
    :focus-visible { outline: 3px solid #2967d0 !important; outline-offset:2px; }
    @media (max-width: 410px) { .mcl-panel { width: min(300px, calc(100vw - 30px)); } }
  `;

  function buildPanel() {
    host = document.createElement('div');
    host.id = 'mcl-lite-host';
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;top:16px;right:16px;max-height:calc(100vh - 24px);pointer-events:auto';
    shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>${CSS_TEXT}</style>
      <button class="mcl-peek" id="peek" type="button" aria-label="Open Course List presets">Course presets &#9656;</button>
      <section class="mcl-panel" id="panel" aria-label="Miami Course List presets">
        <div class="mcl-header">
          <div>
            <h2 class="mcl-heading">Course List presets</h2>
            <div class="mcl-subheading">Miami Course List only &bull; saved locally</div>
          </div>
          <div class="mcl-header-actions">
            <button class="mcl-icon" type="button" id="move" title="Move panel to other side" aria-label="Move panel to other side">&#8646;</button>
            <button class="mcl-icon" type="button" id="collapse" title="Minimize panel" aria-label="Minimize panel">&#8722;</button>
          </div>
        </div>
        <div class="mcl-body">
          <details class="mcl-guide mcl-guide-top">
            <summary>Quick instructions</summary>
            <ol>
              <li>Set Term, Campus, Subject, and any other filters on the page.</li>
              <li>Name the search and press <strong>Save</strong>.</li>
              <li>Click a saved-filter button to restore it, then press <strong>Find courses</strong>.</li>
              <li>Or choose a <strong>Modality</strong> below; it sets the delivery type and runs Find automatically.</li>
              <li>Use <strong>Backup &amp; restore</strong> below to export or import presets between computers or after reinstalling.</li>
            </ol>
            <div class="mcl-small">Only search filter settings are saved. No passwords or account details. Save your current filters as a preset before exporting a backup.</div>
          </details>
          <div class="mcl-section">
            <div class="mcl-label" id="savedHeading">Saved filters</div>
            <div id="quickArea" role="group" aria-labelledby="savedHeading">
              <div class="mcl-quick" id="quick"></div>
            </div>
            <div class="mcl-small" id="emptyPresets" style="display:none">No saved filters yet. Set filters on Course List and save your first preset below.</div>
            <button class="mcl-btn primary" type="button" id="find" style="width:100%;margin-top:10px">Find courses</button>
          </div>
          <div class="mcl-line"></div>
          <div class="mcl-section">
            <label class="mcl-label" for="modality">Modality</label>
            <select class="mcl-select" id="modality">
              <option value="">Choose a modality...</option>
              <option value="any">Any modality (clear filter)</option>
              ${MODALITIES.map(item => `<option value="${item.key}">${item.label}</option>`).join('')}
              <option value="multiple" disabled>Multiple selected on page</option>
            </select>
            <div class="mcl-small" style="margin-top:5px">Selecting a modality updates Course List and automatically runs Find.</div>
          </div>
          <div class="mcl-line"></div>
          <div class="mcl-section">
            <label class="mcl-label" for="name">Save current search as</label>
            <div class="mcl-row">
              <input class="mcl-input" id="name" type="text" maxlength="65" placeholder="e.g., CMR Hamilton" autocomplete="off" />
              <button class="mcl-btn primary" type="button" id="save">Save</button>
            </div>
            <div class="mcl-row" style="margin-top:7px;justify-content:space-between">
              <span class="mcl-small" id="count"></span>
              <button class="mcl-btn compact secondary" type="button" id="delete">Delete selected</button>
            </div>
          </div>
          <label class="mcl-checkbox"><input id="auto" type="checkbox" /><span>Automatically restore the last applied preset when I return</span></label>
          <details class="mcl-guide mcl-backup" id="backupArea">
            <summary>Backup &amp; restore</summary>
            <div class="mcl-backup-body">
              <div class="mcl-small">Save all presets and panel settings to a JSON file. Import that file after reinstalling or on another computer. Normal updates in the same extension folder keep your presets automatically.</div>
              <label class="mcl-label" for="importMode" style="margin-top:9px">When importing</label>
              <select id="importMode" class="mcl-select">
                <option value="replace">Restore everything (replace current)</option>
                <option value="merge">Add presets (keep current settings)</option>
              </select>
              <div class="mcl-backup-actions">
                <button type="button" class="mcl-btn secondary compact" id="exportBackup">Export backup</button>
                <button type="button" class="mcl-btn secondary compact" id="importBackup">Import backup</button>
              </div>
              <input type="file" id="backupFile" accept=".json,application/json" style="display:none" aria-label="Select a Miami Course List backup JSON file" />
              <div class="mcl-small" style="margin-top:7px">Import accepts backup files created by this extension. Unsaved filters on the webpage are not included.</div>
            </div>
          </details>
          <div id="status" class="mcl-status" role="status" aria-live="polite">Ready. Set filters on Course List, then save a preset.</div>

        </div>
      </section>`;
    document.documentElement.append(host);
    ['panel','peek','move','collapse','find','quickArea','quick','emptyPresets','modality','name','save','count','delete','auto','backupArea','exportBackup','importBackup','backupFile','importMode','status'].forEach(k => ui[k] = shadow.getElementById(k));
    ui.collapse.addEventListener('click', () => toggleCollapsed(true));
    ui.peek.addEventListener('click', () => toggleCollapsed(false));
    ui.move.addEventListener('click', async () => {
      await savePreferences({ side: state.side === 'right' ? 'left' : 'right' });
    });
    ui.modality.addEventListener('change', selectModalityAndFind);
    // Keep the dropdown's label synchronized if the site's checkboxes are changed manually.
    document.addEventListener('change', e => {
      if (e.target instanceof HTMLInputElement && e.target.type === 'checkbox' && modalityKeyForCheckbox(e.target)) {
        syncModalityFromPage();
      }
    }, true);
    ui.name.addEventListener('keydown', e => { if (e.key === 'Enter') savePreset(); });
    ui.find.addEventListener('click', () => runFind());
    ui.save.addEventListener('click', savePreset);
    ui.delete.addEventListener('click', deleteSelected);
    ui.exportBackup.addEventListener('click', exportBackup);
    ui.importBackup.addEventListener('click', () => { if (!busy) ui.backupFile.click(); });
    ui.backupFile.addEventListener('change', e => {
      const selectedFile = e.target.files?.[0];
      e.target.value = ''; // Allow importing the same file again.
      if (selectedFile) importBackup(selectedFile);
    });
    ui.auto.addEventListener('change', async () => {
      if (!(await savePreferences({ autoRestore: ui.auto.checked }))) return;
      setStatus(state.autoRestore ? 'Auto-restore enabled. Your last applied preset will return on a future visit.' : 'Auto-restore turned off.', 'ok');
    });
    placeHost();
  }

  function placeHost() {
    if (!host) return;
    host.style.left = state.side === 'left' ? '16px' : 'auto';
    host.style.right = state.side === 'right' ? '16px' : 'auto';
    host.dataset.collapsed = String(!!state.collapsed);
  }
  async function toggleCollapsed(value) {
    if (!(await savePreferences({ collapsed: !!value }))) return;
    if (!value) (ui.quick.querySelector('button') || ui.find).focus();
    else ui.peek.focus();
  }
  async function savePreferences(patch) {
    if (busy) return false;
    busy = true; render();
    try { await commit({action:'preferences', patch}); placeHost(); return true; }
    catch (err) { setStatus('Could not save locally: ' + err.message, 'error'); return false; }
    finally { await finishOperation(); }
  }
  function render() {
    const selected = state.presets.some(p => p.id === state.selectedId);
    ui.count.textContent = state.presets.length + ' saved preset' + (state.presets.length === 1 ? '' : 's');
    ui.delete.disabled = !selected || busy;
    ui.save.disabled = busy;
    for (const key of ['move', 'collapse', 'peek', 'auto']) ui[key].disabled = busy;
    ui.find.disabled = busy;
    ui.modality.disabled = busy;
    ui.exportBackup.disabled = busy;
    ui.importBackup.disabled = busy;
    ui.importMode.disabled = busy;
    if (!busy) ui.auto.checked = !!state.autoRestore;
    renderQuick();
  }
  function renderQuick() {
    const presets = state.presets;
    ui.quickArea.style.display = presets.length ? 'block' : 'none';
    ui.emptyPresets.style.display = presets.length ? 'none' : 'block';
    ui.quick.replaceChildren();
    for (const preset of presets) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = preset.name;
      b.title = 'Restore ' + preset.name;
      b.setAttribute('aria-pressed', String(preset.id === state.selectedId));
      b.setAttribute('aria-current', String(preset.id === state.selectedId));
      b.disabled = busy;
      b.addEventListener('click', () => {
        state.selectedId = preset.id;
        applySelected(false);
      });
      ui.quick.append(b);
    }
    ui.delete.disabled = !state.presets.some(p => p.id === state.selectedId) || busy;
  }

  async function savePreset() {
    if (busy) return;
    const name = norm(ui.name.value);
    if (!name) { setStatus('Enter a name for this preset first.', 'warn'); ui.name.focus(); return; }
    const fields = nativeFieldSnapshot();
    if (!fields.length) { setStatus('No Course List filter fields were detected. Open the search filters on the page and try again.', 'error'); return; }
    const existing = state.presets.find(p => p.name.toLowerCase() === name.toLowerCase());
    if (existing && !window.confirm('Replace the saved preset "' + existing.name + '" with the current filters?')) return;
    if (!existing && state.presets.length >= MAX_PRESETS) { setStatus('Maximum 50 presets reached. Delete an older preset first.', 'warn'); return; }
    const entry = { id: existing?.id || id(), name, fields, savedAt: new Date().toISOString() };
    busy = true; render();
    try {
      await commit({ action: 'save', preset: entry, expected: existing || null });
      ui.name.value = '';
      setStatus('Saved "' + name + '" (' + fields.length + ' controls). Use its quick button to recall it.', 'ok');
    } catch (err) { setStatus('Could not save preset: ' + err.message, 'error'); }
    finally { await finishOperation(); }
  }

  async function applySelected(auto) {
    if (busy) return;
    const preset = state.presets.find(p => p.id === state.selectedId);
    if (!preset) { setStatus('Choose a saved preset first.', 'warn'); return; }
    if (!Array.isArray(preset.fields) || !preset.fields.length) { setStatus('This preset contains no saved filter settings.', 'warn'); return; }
    busy = true;
    render();
    setStatus((auto ? 'Restoring' : 'Applying') + ' "' + preset.name + '"...', 'info');
    try {
      const result = await restoreNativeFields(preset.fields);
      await commit({ action: 'applied', id: preset.id });
      const summary = 'Restored ' + result.completed + ' of ' + result.total + ' filter controls.';
      if (result.missing.length) {
        setStatus(summary + ' Some fields could not be matched or are not yet available: ' + result.missing.slice(0, 4).join(', ') + (result.missing.length > 4 ? ', ...' : '') + '. Check filters before Find.', 'warn');
      } else if (!result.stable) {
        setStatus(summary + ' The page did not settle before the restore deadline. Check filters before Find.', 'warn');
      } else {
        setStatus('Applied "' + preset.name + '". ' + summary + ' Press Find courses when ready.', 'ok');
      }
    } catch (error) { setStatus('Could not fully apply filters: ' + (error?.message || 'unknown error'), 'error'); }
    finally { await finishOperation(); }
  }

  async function deleteSelected() {
    if (busy) return;
    const preset = state.presets.find(p => p.id === state.selectedId);
    if (!preset) return;
    if (!window.confirm('Delete saved preset "' + preset.name + '"?')) return;
    busy = true; render();
    try {
      await commit({ action: 'delete', id: preset.id, expected: preset });
      setStatus('Deleted "' + preset.name + '".', 'ok');
    } catch (err) { setStatus('Could not delete preset: ' + err.message, 'error'); }
    finally { await finishOperation(); }
  }
  function runFind(source = 'manual') {
    const button = findFindButton();
    if (!button || button.disabled) {
      setStatus('Could not use the Course List Find button. Use Find on the page itself.', 'warn');
      return false;
    }
    button.click();
    setStatus(source === 'modality' ? 'Modality selected. Find triggered automatically.' :
      'Course List search submitted using the site\'s Find button.', 'ok');
    return true;
  }

  async function init() {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[STORAGE_KEY] && !busy) refreshState().catch(console.warn);
    });
    await commit({ action: 'read' });
    buildPanel();
    if (state.selectedId && !state.presets.some(p => p.id === state.selectedId)) state.selectedId = null;
    placeHost();
    render();
    syncModalityFromPage();
    if (state.autoRestore && state.lastAppliedId) {
      const last = state.presets.find(p => p.id === state.lastAppliedId);
      if (last) {
        state.selectedId = last.id;
        render();
        await wait(AUTO_RESTORE_DELAY);
        await applySelected(true);
      }
    }
  }
  init().catch(error => console.warn('[Miami Course List Presets] Failed to initialize:', error));
})();
