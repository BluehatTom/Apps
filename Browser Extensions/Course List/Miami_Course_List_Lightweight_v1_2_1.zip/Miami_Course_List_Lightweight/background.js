/* All state mutations run through this worker, one at a time, across all tabs. */
importScripts('data.js');
const STORAGE_KEY = 'mcl_lite_presets_v1';
let queue = Promise.resolve();
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const conflict = () => { throw new Error('This preset or backup target changed in another tab. Check the updated list and try again.'); };
function read() {
  return new Promise((resolve, reject) => chrome.storage.local.get(STORAGE_KEY, data => {
    if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
    else resolve(MCLData.normalize(data?.[STORAGE_KEY]));
  }));
}
function write(state) {
  return new Promise((resolve, reject) => chrome.storage.local.set({[STORAGE_KEY]:state}, () => {
    if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
    else resolve();
  }));
}
function validateImported(imported) {
  return MCLData.parseBackup(JSON.stringify({format:'miami-course-list-lightweight-backup', schemaVersion:1, settings:imported}));
}
async function execute(message) {
  let state = await read();
  let details = {};
  switch (message.action) {
    case 'read': return {ok:true, state};
    case 'preferences':
      for (const key of ['autoRestore','collapsed','side']) {
        if (!Object.hasOwn(message.patch || {}, key)) continue;
        const value = message.patch[key];
        if (key === 'side' ? !['left','right'].includes(value) : typeof value !== 'boolean') throw new Error('Invalid panel preference.');
        state[key] = value;
      }
      break;
    case 'save': {
      const preset = validateImported({presets:[message.preset]}).presets[0];
      const existing = state.presets.find(p => p.id === preset.id) || null;
      if (!equal(existing, message.expected)) conflict();
      if (state.presets.some(p => p.id !== preset.id && p.name.toLowerCase() === preset.name.toLowerCase())) conflict();
      if (!existing && state.presets.length >= 50) throw new Error('Maximum 50 presets reached.');
      state.presets = state.presets.filter(p => p.id !== preset.id).concat(preset);
      state.presets.sort((a,b)=>a.name.localeCompare(b.name));
      state.selectedId = preset.id;
      break;
    }
    case 'delete': {
      const existing = state.presets.find(p => p.id === message.id) || null;
      if (!equal(existing, message.expected)) conflict();
      state.presets = state.presets.filter(p => p.id !== message.id);
      break;
    }
    case 'applied':
      if (state.presets.some(p => p.id === message.id)) state.selectedId = state.lastAppliedId = message.id;
      break;
    case 'replace':
      if (!equal(state, MCLData.normalize(message.expected))) conflict();
      state = validateImported(message.imported);
      break;
    case 'merge': {
      const result = MCLData.mergeBackup(state, validateImported(message.imported));
      state = result.next;
      details = {added:result.added, skipped:result.skipped, renamed:result.renamed};
      break;
    }
    default: throw new Error('Unknown state operation.');
  }
  state = MCLData.normalize(state);
  await write(state);
  return {ok:true, state, ...details};
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.channel !== 'mcl-state') return;
  if (sender.id !== chrome.runtime.id || !/^https:\/\/(?:www\.)?apps\.miamioh\.edu\/courselist\//i.test(sender.url || '')) {
    sendResponse({ok:false,error:'Unsupported extension sender.'});
    return;
  }
  const task = queue.then(() => execute(message));
  queue = task.catch(() => {});
  task.then(sendResponse, error => sendResponse({ok:false,error:error.message}));
  return true;
});
