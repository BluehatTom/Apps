/* Shared backup validation and state operations. */
(() => {
  'use strict';
  const MAX_PRESETS = 50, MAX_FIELDS_PER_PRESET = 400;
  const BACKUP_FORMAT = 'miami-course-list-lightweight-backup', BACKUP_SCHEMA = 1;
  const SENSITIVE_WORDS = /(password|passcode|passwd|security|secret|token|csrf|authenticat|session|captcha|credential|email|phone|user_?id|student_?id)/i;
  const INPUT_TYPES = new Set(['text', 'search', 'number', 'tel', 'url', 'date', 'time', 'datetime-local', 'month', 'week', 'range', 'checkbox', 'radio']);
  const norm = s => String(s ?? '').replace(/\s+/g, ' ').replace(/[\u00a0*]+/g, ' ').trim();
  const id = () => 'p_' + crypto.randomUUID();
  function backupString(v, maximum, label, fallback = '') {
    if (v == null) return fallback;
    if (typeof v !== 'string' || v.length > maximum) throw new Error('Invalid ' + label + ' in backup.');
    return v;
  }

  function backupOption(v) {
    if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('Invalid selected option in backup.');
    return { value: backupString(v.value, 4000, 'option value'), text: backupString(v.text, 4000, 'option text') };
  }

  function backupField(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('Invalid field in backup.');
    if (!['INPUT', 'SELECT', 'TEXTAREA'].includes(raw.tag)) throw new Error('Unknown field type in backup.');
    const type = backupString(raw.type, 30, 'field type');
    if ((raw.tag === 'INPUT' && !INPUT_TYPES.has(type)) || (raw.tag === 'SELECT' && type !== 'select') || (raw.tag === 'TEXTAREA' && type !== 'textarea')) throw new Error('Unsupported filter type in backup.');
    const name = backupString(raw.name, 250, 'field name');
    const idValue = backupString(raw.id, 250, 'field identifier');
    const label = backupString(raw.label, 250, 'field label');
    if (SENSITIVE_WORDS.test([name, idValue, label].join(' '))) throw new Error('The backup includes a field that must not be saved.');
    let value;
    if (type === 'checkbox' || type === 'radio') {
      if (typeof raw.value !== 'boolean') throw new Error('Invalid checkbox value in backup.');
      value = raw.value;
    } else if (raw.tag === 'SELECT') {
      if (Array.isArray(raw.value)) {
        if (raw.value.length > 300) throw new Error('Too many selected options in backup.');
        value = raw.value.map(backupOption);
      } else value = backupOption(raw.value);
    } else {
      value = backupString(raw.value, 10000, 'field value');
    }
    if (!Number.isInteger(raw.ordinal) || raw.ordinal < 0 || raw.ordinal > 1000) throw new Error('Invalid field position in backup.');
    return {
      key: backupString(raw.key, 700, 'field key'), tag: raw.tag, type, name, id: idValue,
      label, ordinal: raw.ordinal, path: backupString(raw.path, 1600, 'field path'),
      optionValue: backupString(raw.optionValue, 4000, 'checkbox option'), value
    };
  }

  function parseBackup(source) {
    let data;
    try { data = JSON.parse(source); } catch { throw new Error('This is not a valid JSON backup file.'); }
    if (!data || typeof data !== 'object' || data.format !== BACKUP_FORMAT) {
      throw new Error('This is not a Miami Course List Lightweight backup.');
    }
    if (data.schemaVersion !== BACKUP_SCHEMA) {
      throw new Error('Unsupported backup format version. Update the extension before importing.');
    }
    const raw = data.settings;
    if (!raw || typeof raw !== 'object' || !Array.isArray(raw.presets)) throw new Error('Backup is missing saved presets.');
    if (raw.presets.length > MAX_PRESETS) throw new Error('Backup has more than 50 presets.');
    const presetIds = new Set();
    const presetNames = new Set();
    const presets = raw.presets.map(item => {
      if (!item || typeof item !== 'object') throw new Error('A saved preset is invalid.');
      const presetId = backupString(item.id, 100, 'preset ID');
      const name = backupString(item.name, 65, 'preset name');
      if (!presetId || !norm(name) || presetIds.has(presetId) || presetNames.has(norm(name).toLowerCase())) {
        throw new Error('Backup contains a missing or duplicate preset ID or name.');
      }
      presetIds.add(presetId);
      presetNames.add(norm(name).toLowerCase());
      if (!Array.isArray(item.fields) || !item.fields.length || item.fields.length > MAX_FIELDS_PER_PRESET) {
        throw new Error('A preset has an invalid number of fields.');
      }
      return {
        id: presetId, name: norm(name), fields: item.fields.map(backupField),
        savedAt: backupString(item.savedAt, 40, 'save date')
      };
    });
    const selectedId = presetIds.has(raw.selectedId) ? raw.selectedId : null;
    const lastAppliedId = presetIds.has(raw.lastAppliedId) ? raw.lastAppliedId : null;
    return {
      presets, selectedId, lastAppliedId,
      autoRestore: raw.autoRestore === true, side: raw.side === 'left' ? 'left' : 'right',
      collapsed: raw.collapsed === true
    };
  }

  function mergeBackup(current, imported) {
    const next = { ...current, presets: current.presets.map(p => ({ ...p })) };
    let added = 0, skipped = 0, renamed = 0;
    const usedIds = new Set(next.presets.map(p => p.id));
    const usedNames = new Set(next.presets.map(p => p.name.toLowerCase()));
    for (const preset of imported.presets) {
      const signature = JSON.stringify(preset.fields);
      const sameContent = p => JSON.stringify(p.fields) === signature;
      const nameMatches = p => {
        if (p.name.toLowerCase() === preset.name.toLowerCase()) return true;
        const suffix = p.name.match(/ \(imported(?: [0-9]+)?\)$/i)?.[0];
        if (!suffix) return false;
        const truncated = preset.name.slice(0, 65 - suffix.length).trimEnd();
        return p.name.slice(0, -suffix.length).toLowerCase() === truncated.toLowerCase();
      };
      if (next.presets.some(p => nameMatches(p) && sameContent(p))) { skipped++; continue; }
      if (next.presets.length >= MAX_PRESETS) throw new Error('Import would exceed 50 presets. Delete some presets or choose Restore everything.');
      let name = preset.name;
      if (usedNames.has(name.toLowerCase())) {
        renamed++;
        let number = 1;
        do {
          const suffix = number === 1 ? ' (imported)' : ' (imported ' + number + ')';
          name = preset.name.slice(0, 65 - suffix.length).trimEnd() + suffix;
          number++;
        } while (usedNames.has(name.toLowerCase()));
      }
      let presetId = preset.id;
      while (usedIds.has(presetId)) presetId = id();
      usedNames.add(name.toLowerCase());
      usedIds.add(presetId);
      next.presets.push({ ...preset, id: presetId, name });
      added++;
    }
    next.presets.sort((a, b) => a.name.localeCompare(b.name));
    return { next, added, skipped, renamed };
  }


  const defaults = () => ({presets:[], selectedId:null, lastAppliedId:null, autoRestore:false, side:'right', collapsed:false});
  function normalize(saved) {
    const result = { ...defaults(), ...(saved && typeof saved === 'object' ? saved : {}) };
    result.presets = Array.isArray(result.presets) ? result.presets.filter(p => p && typeof p.id === 'string' && typeof p.name === 'string' && Array.isArray(p.fields)).slice(0, MAX_PRESETS) : [];
    for (const key of ['selectedId', 'lastAppliedId']) if (!result.presets.some(p => p.id === result[key])) result[key] = null;
    result.side = result.side === 'left' ? 'left' : 'right';
    result.autoRestore = result.autoRestore === true; result.collapsed = result.collapsed === true;
    return result;
  }
  globalThis.MCLData = {backupField, parseBackup, mergeBackup, normalize, INPUT_TYPES};
})();
