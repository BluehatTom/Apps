/* Run with PLAYWRIGHT_MODULE pointing to an installed playwright package.
 * Optional CHROME_PATH overrides the local Chrome executable.
 * Chrome APIs are mocked; the production worker and content scripts are exercised.
 */
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {worker,extension,preset,field,defaults,backup,KEY}=require('./harness.cjs');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const project=path.resolve(__dirname,'../..');
const w=worker(); const errors=[]; let context; let passed=0; let acceptDialog=true;
const fixture=`<!doctype html><html><head><title>Course List fixture</title><style>form{max-width:600px}fieldset label{display:block}</style></head><body>
<form id="filters"><label for="term">Term</label><select id="term" name="term"><option value="fall">Fall 2026</option><option value="spring">Spring 2027</option></select>
<label for="campus">Campus</label><select id="campus" name="campus"><option value="O">Oxford</option><option value="H">Hamilton</option></select>
<label for="subject">Subject</label><select id="subject" name="subject"><option value="ENG">English</option><option value="CMR">Commerce</option></select>
<label for="course">Course Number</label><input id="course" name="course" value="111">
<label for="account">Email</label><input id="account" name="account" value="private@example.com">
<input type="hidden" id="courseFilter" name="csrf" value="secret">
<fieldset><legend>Alternative Delivery Types</legend>
${['Face-to-Face','Online Synchronous','Online Asynchronous','Hybrid Synchronous','Hybrid Asynchronous','Interactive Video Dist Learn','Study Abroad','Study Away'].map((label,i)=>`<label><input type="checkbox" name="delivery" value="${i}">${label}</label>`).join('')}
</fieldset><button type="submit">Find</button></form>
<script>window.findCount=0;window.resetCount=0;
document.getElementById('filters').addEventListener('submit',e=>{e.preventDefault();window.findCount++});
document.getElementById('campus').addEventListener('change',()=>setTimeout(()=>{
 const replacement=document.getElementById('subject').cloneNode(true); replacement.value='ENG';
 document.getElementById('subject').replaceWith(replacement);window.resetCount++;
},450));</script></body></html>`;
const ui=(page,id)=>page.locator('#mcl-lite-host').locator('#'+id);
async function ready(page){await ui(page,'save').waitFor();}
async function idle(page){await page.waitForFunction(()=>!document.getElementById('mcl-lite-host').shadowRoot.getElementById('save').disabled);}
async function status(page,text){await page.waitForFunction(text=>document.getElementById('mcl-lite-host').shadowRoot.getElementById('status').textContent.includes(text),text);}
async function check(label,fn){await fn();console.log('PASS '+label);passed++;}
async function load(page){
  page.on('pageerror',error=>errors.push(error.message));
  page.on('dialog',dialog=>acceptDialog ? dialog.accept() : dialog.dismiss());
  await page.goto('https://www.apps.miamioh.edu/courselist/');
  await page.addScriptTag({path:path.join(extension,'data.js')});
  await page.addScriptTag({path:path.join(extension,'content.js')});
  await ready(page);
}
async function main(){
  const scratch=path.join(project,'work/browser-profile');
  context=await chromium.launchPersistentContext(scratch,{executablePath:process.env.CHROME_PATH || 'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,acceptDownloads:true});
  await context.route('**/*',route=>route.request().url().startsWith('https://www.apps.miamioh.edu/courselist/') ? route.fulfill({contentType:'text/html',body:fixture}) : route.abort());
  await context.exposeBinding('sendOperation',(_,message)=>w.send(message));
  await context.exposeBinding('getStored',()=>w.get());
  await context.addInitScript(key=>{
    const listeners=[];
    window.chrome={runtime:{sendMessage(message,cb){window.sendOperation(message).then(cb);}},storage:{
      local:{get(key,cb){window.getStored().then(state=>cb({[key]:state}));}},
      onChanged:{addListener(fn){listeners.push(fn);}}
    }};
    window.notifyStorage=(changes,area)=>listeners.forEach(fn=>fn(changes,area));
  },KEY);
  w.listeners.push((changes,area)=>{for(const page of context.pages()) page.evaluate(({changes,area})=>window.notifyStorage?.(changes,area),{changes,area}).catch(()=>{});});
  const a=await context.newPage(),b=await context.newPage();await load(a);await load(b);
  await check('real DOM save excludes sensitive fields',async()=>{
    await a.selectOption('#campus','H');await a.waitForFunction(()=>window.resetCount===1);await a.selectOption('#subject','CMR');
    await ui(a,'name').fill('Hamilton CMR');await ui(a,'save').click();await status(a,'Saved "Hamilton CMR"');await idle(a);
    assert.equal(w.get().presets.length,1);
    assert.ok(!w.get().presets[0].fields.some(f=>f.id==='account'||f.id==='courseFilter'));
  });
  await check('cross-tab synchronization and panel preference preserves presets',async()=>{
    await ui(b,'quick').getByRole('button',{name:'Hamilton CMR'}).waitFor();
    await ui(b,'collapse').click();await ui(b,'peek').waitFor();assert.equal(w.get().presets.length,1);
    await ui(b,'peek').click();await idle(b);await ui(a,'panel').waitFor();
  });
  await check('asynchronous Campus reset is repaired before restore success',async()=>{
    await a.selectOption('#campus','O');await a.waitForFunction(()=>window.resetCount===2);await a.selectOption('#subject','ENG');
    await ui(a,'quick').getByRole('button',{name:'Hamilton CMR'}).click();await status(a,'Applied "Hamilton CMR"');await idle(a);
    assert.equal(await a.locator('#subject').inputValue(),'CMR');assert.equal(await a.locator('#campus').inputValue(),'H');
    await a.waitForTimeout(600);assert.equal(await a.locator('#subject').inputValue(),'CMR');
  });
  await check('simultaneous browser saves preserve both new presets',async()=>{
    await ui(a,'name').fill('Tab A');await ui(b,'name').fill('Tab B');
    await Promise.all([ui(a,'save').click(),ui(b,'save').click()]);
    await status(a,'Saved "Tab A"');await status(b,'Saved "Tab B"');await idle(a);await idle(b);
    assert.equal(w.get().presets.length,3);
  });
  await check('failed write shows an error without phantom data',async()=>{
    w.setFailWrite(true);await ui(a,'name').fill('Should fail');await ui(a,'save').click();await status(a,'Storage full');await idle(a);
    assert.equal(w.get().presets.length,3);assert.equal(await ui(a,'name').inputValue(),'Should fail');w.setFailWrite(false);
  });
  let exported;
  await check('backup downloads real JSON with current data',async()=>{
    await ui(a,'backupArea').locator('summary').click();const download=a.waitForEvent('download');await ui(a,'exportBackup').click();
    const file=await download;exported=fs.readFileSync(await file.path(),'utf8');const parsed=JSON.parse(exported);
    assert.equal(parsed.extensionVersion,'1.2.1');assert.equal(parsed.settings.presets.length,3);
  });
  await check('backup merges without duplicate presets',async()=>{
    await ui(a,'importMode').selectOption('merge');
    await ui(a,'backupFile').setInputFiles({name:'roundtrip.json',mimeType:'application/json',buffer:Buffer.from(exported)});
    await status(a,'Added 0 presets; skipped 3');await idle(a);assert.equal(w.get().presets.length,3);
  });
  await check('crafted hidden-field backup is rejected without changing page or storage',async()=>{
    const bad=backup({...defaults(),presets:[{...preset('evil','Crafted'),fields:[field({type:'hidden',id:'courseFilter',name:'',value:'overwritten'})]}]});
    await ui(a,'backupFile').setInputFiles({name:'bad.json',mimeType:'application/json',buffer:Buffer.from(bad)});
    await status(a,'Unsupported filter type');await idle(a);
    assert.equal(w.get().presets.length,3);assert.equal(await a.locator('#courseFilter').inputValue(),'secret');
  });
  await check('missing delivery option warns instead of changing an unrelated option',async()=>{
    await a.locator('input[name="delivery"][value="7"]').check();await ui(a,'name').fill('Away');await ui(a,'save').click();await status(a,'Saved "Away"');await idle(a);
    await a.locator('input[name="delivery"][value="7"]').evaluate(el=>el.remove());
    await ui(a,'quick').getByRole('button',{name:'Away',exact:true}).click();await status(a,'Some fields could not be matched');await idle(a);
    assert.equal(await a.locator('input[name="delivery"]:checked').count(),0);
  });
  await check('modality selection still updates controls and submits Find',async()=>{
    const before=await b.evaluate(()=>window.findCount);await ui(b,'modality').selectOption('online-async');
    await status(b,'Find triggered automatically');await idle(b);
    assert.equal(await b.locator('input[name="delivery"]:checked').inputValue(),'2');
    assert.equal(await b.evaluate(()=>window.findCount),before+1);
  });
  await check('cancelled replacement leaves existing presets intact',async()=>{
    await ui(a,'importMode').selectOption('replace');acceptDialog=false;
    await ui(a,'backupFile').setInputFiles({name:'restore.json',mimeType:'application/json',buffer:Buffer.from(exported)});
    await status(a,'Import canceled');await idle(a);acceptDialog=true;assert.equal(w.get().presets.length,4);
  });
  await check('confirmed replacement restores exported presets',async()=>{
    await ui(a,'backupFile').setInputFiles({name:'restore.json',mimeType:'application/json',buffer:Buffer.from(exported)});
    await status(a,'Restored 3 presets');await idle(a);assert.equal(w.get().presets.length,3);
  });
  await check('auto-restore still works on a new page',async()=>{
    await ui(b,'quick').getByRole('button',{name:'Hamilton CMR',exact:true}).click();await status(b,'Applied "Hamilton CMR"');await idle(b);
    await ui(b,'auto').check();await status(b,'Auto-restore enabled');await idle(b);
    const c=await context.newPage();await load(c);await status(c,'Applied "Hamilton CMR"');await idle(c);
    assert.equal(await c.locator('#subject').inputValue(),'CMR');assert.equal(await c.evaluate(()=>window.findCount),0);
  });
  assert.deepEqual(errors,[]);console.log('Browser checks passed: '+passed+'; page errors: 0');
}
main().catch(error=>{console.error(error);process.exitCode=1;}).finally(async()=>{if(context)await context.close();});
