const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto').webcrypto;
const extension = path.resolve(__dirname, '../Miami_Course_List_Lightweight');
const KEY = 'mcl_lite_presets_v1';
const defaults = () => ({presets:[], selectedId:null, lastAppliedId:null, autoRestore:false, side:'right', collapsed:false});
function worker(initial = defaults()) {
  let stored = structuredClone(initial), listener, failWrite = false, failRead = false;
  const listeners = [];
  const runtime = {id:'test-extension', onMessage:{addListener(fn){listener=fn;}}};
  const context = vm.createContext({console, crypto, chrome:{runtime, storage:{local:{
    get(key, cb) { setTimeout(() => {
      if(failRead) runtime.lastError={message:'Read failure'};
      cb({[KEY]:structuredClone(stored)}); delete runtime.lastError;
    }, 2); },
    set(data, cb) { setTimeout(() => {
      if(failWrite) { runtime.lastError={message:'Storage full'}; cb(); delete runtime.lastError; return; }
      const oldValue = stored; stored = structuredClone(data[KEY]);
      for(const fn of listeners) fn({[KEY]:{oldValue,newValue:stored}},'local');
      cb();
    }, 2); }
  }}}});
  context.importScripts = file => vm.runInContext(fs.readFileSync(path.join(extension,file),'utf8'),context,{filename:file});
  context.importScripts('background.js');
  function send(message, sender={id:runtime.id,url:'https://www.apps.miamioh.edu/courselist/'}) {
    return new Promise(resolve=>listener({channel:'mcl-state',...structuredClone(message)},sender,result=>resolve(structuredClone(result))));
  }
  return {send, listeners, get:()=>structuredClone(stored), setFailWrite:value=>{failWrite=value;}, setFailRead:value=>{failRead=value;}, data:context.MCLData};
}
function field(overrides={}) { return {key:'input|text|course|0', tag:'INPUT',type:'text',name:'course',id:'course',label:'Course Number',ordinal:0,path:'input#course',optionValue:'',value:'111',...overrides}; }
function preset(id='a',name='Preset A') { return {id,name,fields:[field()],savedAt:'2026-10-30T00:00:00.000Z'}; }
function backup(settings) {return JSON.stringify({format:'miami-course-list-lightweight-backup',schemaVersion:1,extensionVersion:'1.2.0',settings});}
module.exports={worker,defaults,field,preset,backup,extension,KEY};
