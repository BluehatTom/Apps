const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {worker,defaults,field,preset,backup,extension}=require('./harness.cjs');
test('stale-tab preference update preserves a new preset',async()=>{
  const w=worker();
  assert.equal((await w.send({action:'save',preset:preset(),expected:null})).ok,true);
  assert.equal((await w.send({action:'preferences',patch:{collapsed:true}})).ok,true);
  assert.equal(w.get().presets.length,1); assert.equal(w.get().collapsed,true);
});
test('simultaneous saves from multiple tabs are serialized',async()=>{
  const w=worker();
  const result=await Promise.all(Array.from({length:20},(_,i)=>w.send({action:'save',preset:preset('p'+i,'Preset '+i),expected:null})));
  assert.ok(result.every(r=>r.ok)); assert.equal(w.get().presets.length,20);
});
test('conflicting overwrite is rejected without deleting either tab data',async()=>{
  const w=worker({...defaults(),presets:[preset()]});
  const updated={...preset(),fields:[field({value:'222'})]};
  assert.equal((await w.send({action:'save',preset:updated,expected:preset()})).ok,true);
  assert.equal((await w.send({action:'save',preset:{...preset(),fields:[field({value:'333'})]},expected:preset()})).ok,false);
  assert.equal(w.get().presets[0].fields[0].value,'222');
});
test('stale delete and duplicate-name save are rejected',async()=>{
  const w=worker({...defaults(),presets:[preset()]});
  assert.equal((await w.send({action:'delete',id:'a',expected:{...preset(),name:'Old'}})).ok,false);
  assert.equal((await w.send({action:'save',preset:preset('b'),expected:null})).ok,false);
  assert.equal(w.get().presets.length,1);
});
test('delete cleans selection and last-applied references',async()=>{
  const w=worker({...defaults(),presets:[preset()],selectedId:'a',lastAppliedId:'a'});
  assert.equal((await w.send({action:'delete',id:'a',expected:preset()})).ok,true);
  assert.equal(w.get().selectedId,null); assert.equal(w.get().lastAppliedId,null);
});
test('stale whole-backup replacement is rejected',async()=>{
  const w=worker(); const expected=w.get();
  await w.send({action:'save',preset:preset(),expected:null});
  assert.equal((await w.send({action:'replace',imported:defaults(),expected})).ok,false);
  assert.equal(w.get().presets.length,1);
});
test('confirmed backup replacement succeeds when current state matches',async()=>{
  const w=worker(); const imported={...defaults(),presets:[preset()],side:'left'};
  assert.equal((await w.send({action:'replace',imported,expected:w.get()})).ok,true);
  assert.equal(w.get().side,'left'); assert.equal(w.get().presets.length,1);
});
test('concurrent backup merges preserve settings, deduplicate, and rename conflicts',async()=>{
  const w=worker({...defaults(),side:'left',presets:[preset()]});
  const imported={...defaults(),presets:[{...preset('b'),fields:[field({value:'222'})]}]};
  const results=await Promise.all([w.send({action:'merge',imported}),w.send({action:'merge',imported})]);
  assert.ok(results.every(r=>r.ok)); assert.equal(w.get().presets.length,2);
  assert.equal(results[1].skipped,1); assert.equal(w.get().side,'left');
  assert.equal(w.get().presets[1].name,'Preset A (imported)');
});
test('maximum count enforced against latest state',async()=>{
  const w=worker({...defaults(),presets:Array.from({length:49},(_,i)=>preset('p'+i,'P '+i))});
  const results=await Promise.all(['a','b'].map(id=>w.send({action:'save',preset:preset(id,id),expected:null})));
  assert.equal(results.filter(r=>r.ok).length,1); assert.equal(w.get().presets.length,50);
});
test('failed writes preserve data and do not poison the operation queue',async()=>{
  const w=worker();w.setFailWrite(true);
  assert.equal((await w.send({action:'save',preset:preset(),expected:null})).ok,false);
  assert.equal(w.get().presets.length,0);w.setFailWrite(false);
  assert.equal((await w.send({action:'save',preset:preset(),expected:null})).ok,true);
});
test('failed reads cannot overwrite data',async()=>{
  const w=worker({...defaults(),presets:[preset()]});w.setFailRead(true);
  assert.equal((await w.send({action:'preferences',patch:{collapsed:true}})).ok,false);
  assert.equal(w.get().presets.length,1);assert.equal(w.get().collapsed,false);
});
test('legacy v1.2.0 backup round trip preserves supported fields',()=>{
  const w=worker();const settings={...defaults(),presets:[preset()]};
  const parsed=w.data.parseBackup(backup(settings));
  assert.equal(JSON.stringify(parsed),JSON.stringify(settings));
});
test('import and worker reject hidden/password and incompatible tag/type descriptors',async()=>{
  const w=worker();
  for(const change of [{type:'hidden'},{type:'password'},{tag:'SELECT',type:'checkbox'},{tag:'TEXTAREA',type:'radio'}]) {
    const p={...preset(),fields:[field(change)]};
    assert.throws(()=>w.data.parseBackup(backup({...defaults(),presets:[p]})));
    assert.equal((await w.send({action:'save',preset:p,expected:null})).ok,false);
  }
  assert.equal(w.get().presets.length,0);
});
test('invalid schema and duplicate names leave existing presets untouched',async()=>{
  const w=worker({...defaults(),presets:[preset()]});
  assert.throws(()=>w.data.parseBackup('{}'));
  const imported={...defaults(),presets:[preset('b'),preset('c')]};
  assert.equal((await w.send({action:'merge',imported})).ok,false);
  assert.equal(w.get().presets[0].id,'a');
});
test('unsupported sender is rejected',async()=>{
  const w=worker();
  const result=await w.send({action:'preferences',patch:{collapsed:true}},{id:'other-extension',url:'https://example.com/'});
  assert.equal(result.ok,false); assert.equal(w.get().collapsed,false);
});
function content() {
  const document={getElementById:()=>null};
  const context=vm.createContext({document,window:{},location:{hostname:'www.apps.miamioh.edu',pathname:'/courselist/'},console});
  context.window.top=context.window.self=context.window;
  vm.runInContext(fs.readFileSync(path.join(extension,'data.js'),'utf8'),context);
  const source=fs.readFileSync(path.join(extension,'content.js'),'utf8').replace("  init().catch(error => console.warn('[Miami Course List Presets] Failed to initialize:', error));",'  globalThis.testApi={findField,isRelevant};');
  vm.runInContext(source,context);return context;
}
function input(value,label,id='') {return {tagName:'INPUT',type:'checkbox',name:'delivery',id,value,isConnected:true,labels:[{textContent:label}],getAttribute:()=>null,closest:()=>null};}
test('missing checkbox values never fall back to ordinal, ID, label, or path',()=>{
  const c=content();const options=[input('face','Face-to-Face','away'),input('online','Study Away')];
  c.document.getElementById=()=>options[0];
  const root={querySelectorAll:()=>options,contains:()=>true,querySelector:()=>options[1]};
  const result=c.testApi.findField(field({type:'checkbox',name:'delivery',id:'away',label:'Study Away',optionValue:'removed',ordinal:1,value:true}),{root,confident:true});
  assert.equal(result,null);
});
test('reordered checkbox group matches saved value',()=>{
  const c=content();const options=[input('online','Online'),input('away','Study Away')];
  const root={querySelectorAll:()=>options,contains:()=>true};
  const result=c.testApi.findField(field({type:'checkbox',name:'delivery',label:'Study Away',optionValue:'away',ordinal:0,value:true}),{root,confident:true});
  assert.equal(result,options[1]);
});
test('ID fallback rejects hidden and sensitive actual targets',()=>{
  const c=content();const root={querySelectorAll:()=>[],contains:()=>true,querySelector:()=>null};
  for(const attrs of [{type:'hidden',name:'course'},{type:'text',name:'csrf'},{type:'text',name:'course',labels:[{textContent:'Email'}]}]) {
    const target={...input('x','Course','course'),...attrs}; c.document.getElementById=()=>target;
    assert.equal(c.testApi.findField(field({type:target.type}),{root,confident:true}),null);
  }
});
