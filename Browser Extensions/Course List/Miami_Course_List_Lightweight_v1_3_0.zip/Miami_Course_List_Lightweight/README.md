# Miami Course List Lightweight - v1.3.0

A compact Chrome/Edge extension for Miami University's public Course List. This release adds a **Major or minor** dropdown with six programs, course group choices for Digital Commerce, and elective selection for the Commerce Minor. Existing **saved-preset buttons, Modality, Find, auto-restore, export/import backup, and panel controls** are retained.

**Website:** https://www.apps.miamioh.edu/courselist/

## Update an existing extension without losing presets

1. Open Course List with v1.2.0 installed. If possible, use **Backup & restore > Export backup** to save your current presets first.
2. Extract `Miami_Course_List_Lightweight_v1_3_0.zip` somewhere temporary.
3. Copy the new `content.js`, `manifest.json`, and `README.md` files into the **same folder currently used by your loaded extension**, replacing the older files. Do **not** uninstall the existing extension.
4. In `chrome://extensions` (or `edge://extensions`), select **Reload** for the extension.
5. Refresh Course List. Your saved presets should remain intact.

**Why this matters:** Chrome/Edge may assign a new extension identity if you load the extension from a different folder. This version retains the original Chrome storage key (`mcl_lite_presets_v1`), original preset format, and backup schema 1. Normal in-place updates retain saved presets. You can import a backup JSON file if you reinstall or use another computer.

### New installation

1. Extract the ZIP to a permanent folder.
2. Open `chrome://extensions` or `edge://extensions`.
3. Enable **Developer mode**, click **Load unpacked**, and choose the extracted `Miami_Course_List_Lightweight` folder containing `manifest.json`.
4. Visit https://www.apps.miamioh.edu/courselist/ and refresh if necessary.

## Major or minor dropdown (NEW)

Select **Term** and **Campus** on the actual Course List page first. Next, select a program under **Major or minor** in the side panel. The extension updates the site's **Subject** and **Course Number** controls, verifies the changes, and presses the site's **Find** button automatically.

**Term and Campus are not changed by the program selector.** Modality and other filters also remain in place, allowing a program search to be narrowed by modality or instructor. If a filter is already restrictive, it can reduce the results.

| Program | Searchable courses |
| --- | --- |
| Small Business Management Major | CMR 242, 263, 301, 361, 442, 446 |
| Sales Management Major | CMR 261, 263, 301, 362, 363, 461 |
| Sales Management Minor | CMR 105, 261, 263, 362, 363, 461 |
| Digital Commerce Major | CMR 242, 286, 341, 449, plus CMR 281 **or** IMS 392, and CMR 285 **or** IMS 414 |
| Digital Commerce Minor | CMR 105, 281, 285, 286, 341, 442 |
| Commerce Minor | CMR 105, 111, 302, plus **choose three** from CMR 101, 108, 207, 211, 244, 282, 495 |

These course groups were specified for this extension; verify actual program requirements with the applicable university catalog. This is **not a degree audit** and does not enforce prerequisites or count credits.

### Digital Commerce Major - either/or substitutions

Two extra dropdowns let you choose for each requirement:

- **CMR 281 or IMS 392:** Show both options (default), CMR 281 only, or IMS 392 only.
- **CMR 285 or IMS 414:** Show both options (default), CMR 285 only, or IMS 414 only.

A third dropdown, **Search subject**, switches between **CMR courses** and **IMS alternatives**. When there are no IMS options left, the IMS group is disabled. Every change applies the corresponding group to the Course List page and runs Find automatically.

**Why two searches?** Miami Course List allows comma-delimited course numbers and multiple subjects. Searching CMR and IMS together would apply **every number** to both subjects, potentially returning irrelevant combinations such as CMR 392 and IMS 242. Separate searches prevent those false matches while still allowing both alternatives to be reviewed.

### Commerce Minor - choose three electives

The default search includes CMR 105, 111, 302 and **all seven eligible elective options** so you can compare which are offered.

Change **Elective options (choose 3)** to **Filter to my 3 selected electives** to display checkboxes for CMR 101, 108, 207, 211, 244, 282, and 495. Select any three. Once three are selected, Course Number contains the three required courses **plus exactly those three electives**. If fewer than three are selected, the search temporarily shows all seven candidates. The panel prevents selecting a fourth. Each valid change updates filters and runs Find.

## Other controls retained

- **Quick instructions** remain at the top of the panel.
- **Saved filters** are buttons, not a saved-filter dropdown. Clicking one restores the saved site's filter values **without** running Find. The program dropdown clears when recalling a preset to avoid implying that the chosen program is still active.
- **Find courses** runs the website's native Find action.
- **Modality** sets one of the eight site's Alternative Delivery Types (or clears delivery filtering) and runs Find automatically.
- **Save current search as** captures the site's existing filter values (including Subject and Course Number that the program selector just populated). Name and save presets for future one-click recall.
- **Auto-restore** restores the last applied saved preset on a future visit. It does not run Find automatically.
- **Backup & restore** exports JSON backup files and imports them in **replace** or **merge** mode. Exports include named presets and panel preferences. Program picks are reflected in backups **only if saved as a named filter preset first**.
- **Move panel / Minimize** are unchanged.

## Reliability, privacy, and compatibility

- Runs only on `https://www.apps.miamioh.edu/courselist/` and `https://apps.miamioh.edu/courselist/`.
- Keeps browser data locally through `chrome.storage.local`; it neither connects to an outside server nor requests a password/API key.
- Program filters work with standard multiple-selects, some site-style multiselect dropdowns, or a labeled Subject checkbox fieldset. If Subject or Course Number cannot be identified or verified, the extension **does not automatically run Find** and displays an error rather than potentially searching the wrong courses.
- Uses the website's own Find control; results, course availability, and registration conditions come from the university page.
- **Local browser testing:** 47 checks passed, covering all six programs, CMR/IMS alternatives, three-elective selection, unchanged Term/Campus, modal filtering, preset saving/recall, backup export control, failure-safe behavior, and common Subject control styles. **Live-site compatibility is not yet verified against an authenticated browser session.** If the university changes its markup, adaptation may be required.

## Version history

- v1.0: Course List-only filter preset buttons and side panel.
- v1.0.1: Quick instructions moved to the top.
- v1.1.0: Modality dropdown with automatic Find; removed saved preset dropdown.
- v1.2.0: Portable backup export/import, replacement or merge restore.
- **v1.3.0:** Six major/minor options, Digital Commerce alternates, and Commerce Minor elective selection.
